package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 600, 600);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _button1 = null;
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
 //BA.debugLineNum = 16;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 17;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 18;BA.debugLine="MainForm.RootPane.LoadLayout(\"Layout1\")";
_mainform.getRootPane().LoadLayout(ba,"Layout1");
 //BA.debugLineNum = 19;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return "";
}
public static String  _base64encode(String _s) throws Exception{
int _c = 0;
String _base64chars = "";
String _p = "";
String _r = "";
int _n = 0;
int _n1 = 0;
int _n2 = 0;
int _n3 = 0;
int _n4 = 0;
 //BA.debugLineNum = 58;BA.debugLine="Public Sub Base64Encode(S As String) As String";
 //BA.debugLineNum = 59;BA.debugLine="Dim c As Int = S.Length Mod 3";
_c = (int) (_s.length()%3);
 //BA.debugLineNum = 60;BA.debugLine="Dim base64chars As String = \"ABCDEFGHIJKLMNOPQRST";
_base64chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
 //BA.debugLineNum = 61;BA.debugLine="Dim P = \"\",R = \"\" As String";
_p = "";
_r = "";
 //BA.debugLineNum = 64;BA.debugLine="If c>0 Then";
if (_c>0) { 
 //BA.debugLineNum = 65;BA.debugLine="Do While c<3";
while (_c<3) {
 //BA.debugLineNum = 66;BA.debugLine="P = P & \"=\"";
_p = _p+"=";
 //BA.debugLineNum = 67;BA.debugLine="S = S & \"0\"";
_s = _s+"0";
 //BA.debugLineNum = 68;BA.debugLine="c=c+1";
_c = (int) (_c+1);
 }
;
 };
 //BA.debugLineNum = 72;BA.debugLine="For c = 0 To S.Length-1 Step 3";
{
final int step11 = 3;
final int limit11 = (int) (_s.length()-1);
_c = (int) (0) ;
for (;_c <= limit11 ;_c = _c + step11 ) {
 //BA.debugLineNum = 73;BA.debugLine="If (c > 0 And (c / 3 * 4) Mod 76 = 0) Then R=R &";
if ((_c>0 && (_c/(double)3*4)%76==0)) { 
_r = _r+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (10)))+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (13)));};
 //BA.debugLineNum = 74;BA.debugLine="Dim n As Int = Bit.ShiftLeft(Asc(S.CharAt(c)),16";
_n = (int) (anywheresoftware.b4a.keywords.Common.Bit.ShiftLeft(anywheresoftware.b4a.keywords.Common.Asc(_s.charAt(_c)),(int) (16))+anywheresoftware.b4a.keywords.Common.Bit.ShiftLeft(anywheresoftware.b4a.keywords.Common.Asc(_s.charAt((int) (_c+1))),(int) (8))+anywheresoftware.b4a.keywords.Common.Asc(_s.charAt((int) (_c+2))));
 //BA.debugLineNum = 75;BA.debugLine="Dim n1 As Int = Bit.And(Bit.ShiftRight(n,18),63)";
_n1 = anywheresoftware.b4a.keywords.Common.Bit.And(anywheresoftware.b4a.keywords.Common.Bit.ShiftRight(_n,(int) (18)),(int) (63));
 //BA.debugLineNum = 76;BA.debugLine="Dim n2 As Int = Bit.And(Bit.ShiftRight(n,12),63)";
_n2 = anywheresoftware.b4a.keywords.Common.Bit.And(anywheresoftware.b4a.keywords.Common.Bit.ShiftRight(_n,(int) (12)),(int) (63));
 //BA.debugLineNum = 77;BA.debugLine="Dim n3 As Int = Bit.And(Bit.ShiftRight(n,6),63)";
_n3 = anywheresoftware.b4a.keywords.Common.Bit.And(anywheresoftware.b4a.keywords.Common.Bit.ShiftRight(_n,(int) (6)),(int) (63));
 //BA.debugLineNum = 78;BA.debugLine="Dim n4 As Int = Bit.And(n,63)";
_n4 = anywheresoftware.b4a.keywords.Common.Bit.And(_n,(int) (63));
 //BA.debugLineNum = 80;BA.debugLine="R = R & base64chars.CharAt(n1) & base64chars.Cha";
_r = _r+BA.ObjectToString(_base64chars.charAt(_n1))+BA.ObjectToString(_base64chars.charAt(_n2))+BA.ObjectToString(_base64chars.charAt(_n3))+BA.ObjectToString(_base64chars.charAt(_n4));
 }
};
 //BA.debugLineNum = 82;BA.debugLine="Return r.substring2(0, r.length - p.length) & p";
if (true) return _r.substring((int) (0),(int) (_r.length()-_p.length()))+_p;
 //BA.debugLineNum = 83;BA.debugLine="End Sub";
return "";
}
public static String  _button1_click() throws Exception{
String _header = "";
String _h = "";
String _payload = "";
String _p = "";
String _mykey = "";
String _signature = "";
String _s = "";
 //BA.debugLineNum = 22;BA.debugLine="Sub Button1_Click";
 //BA.debugLineNum = 31;BA.debugLine="Dim header,h As String";
_header = "";
_h = "";
 //BA.debugLineNum = 33;BA.debugLine="header = $\"{\"alg\":\"HS256\",\"typ\":\"JWT\"}\"$";
_header = ("{\"alg\":\"HS256\",\"typ\":\"JWT\"}");
 //BA.debugLineNum = 34;BA.debugLine="h=Base64Encode(header)";
_h = _base64encode(_header);
 //BA.debugLineNum = 35;BA.debugLine="Log(\"base64Url Header=> \"&h)";
anywheresoftware.b4a.keywords.Common.LogImpl("6131085","base64Url Header=> "+_h,0);
 //BA.debugLineNum = 38;BA.debugLine="Dim payload,p As String";
_payload = "";
_p = "";
 //BA.debugLineNum = 40;BA.debugLine="payload = $\"{\"sub\":\"1234567890\",\"name\":\"John Doe\"";
_payload = ("{\"sub\":\"1234567890\",\"name\":\"John Doe\",\"admin\":true}");
 //BA.debugLineNum = 41;BA.debugLine="p=Base64Encode(payload)";
_p = _base64encode(_payload);
 //BA.debugLineNum = 42;BA.debugLine="Log(\"base64Url Payload=>  \"&p)";
anywheresoftware.b4a.keywords.Common.LogImpl("6131092","base64Url Payload=>  "+_p,0);
 //BA.debugLineNum = 44;BA.debugLine="Dim mykey As String = \"secret\"";
_mykey = "secret";
 //BA.debugLineNum = 45;BA.debugLine="Dim signature As String=h&\".\"&p";
_signature = _h+"."+_p;
 //BA.debugLineNum = 46;BA.debugLine="Dim s As String";
_s = "";
 //BA.debugLineNum = 49;BA.debugLine="Log(\"簽章==> \" &signature)";
anywheresoftware.b4a.keywords.Common.LogImpl("6131099","簽章==> "+_signature,0);
 //BA.debugLineNum = 51;BA.debugLine="s = getHashBase64(CreateHash(mykey,\"HMACSHA256\",s";
_s = _gethashbase64(_createhash(_mykey,"HMACSHA256",_signature,"ASCII"));
 //BA.debugLineNum = 52;BA.debugLine="Log(\"base64Url signature=> \" &s)";
anywheresoftware.b4a.keywords.Common.LogImpl("6131102","base64Url signature=> "+_s,0);
 //BA.debugLineNum = 54;BA.debugLine="Log(\"jwt token=> \" & h &\".\"& p &\".\"& s  )";
anywheresoftware.b4a.keywords.Common.LogImpl("6131104","jwt token=> "+_h+"."+_p+"."+_s,0);
 //BA.debugLineNum = 55;BA.debugLine="End Sub";
return "";
}
public static String  _createhash(String _key,String _algorithm,String _data,String _charset) throws Exception{
anywheresoftware.b4a.agraham.encryption.CipherWrapper.MacWrapper _m = null;
anywheresoftware.b4a.agraham.encryption.CipherWrapper.KeyGeneratorWrapper _k = null;
anywheresoftware.b4a.agraham.byteconverter.ByteConverter _bc = null;
byte[] _b = null;
 //BA.debugLineNum = 104;BA.debugLine="Sub CreateHash(key As String,algorithm As String,d";
 //BA.debugLineNum = 106;BA.debugLine="Dim m As Mac";
_m = new anywheresoftware.b4a.agraham.encryption.CipherWrapper.MacWrapper();
 //BA.debugLineNum = 107;BA.debugLine="Dim k As KeyGenerator";
_k = new anywheresoftware.b4a.agraham.encryption.CipherWrapper.KeyGeneratorWrapper();
 //BA.debugLineNum = 108;BA.debugLine="Dim bc As ByteConverter";
_bc = new anywheresoftware.b4a.agraham.byteconverter.ByteConverter();
 //BA.debugLineNum = 109;BA.debugLine="k.Initialize(algorithm)";
_k.Initialize(_algorithm);
 //BA.debugLineNum = 110;BA.debugLine="k.KeyFromBytes(key.GetBytes(charset))";
_k.KeyFromBytes(_key.getBytes(_charset));
 //BA.debugLineNum = 111;BA.debugLine="m.Initialise(algorithm, k.Key)";
_m.Initialise(_algorithm,(java.security.Key)(_k.getKey()));
 //BA.debugLineNum = 112;BA.debugLine="m.Update(data.GetBytes(charset))";
_m.Update(_data.getBytes(_charset));
 //BA.debugLineNum = 113;BA.debugLine="Dim b() As Byte";
_b = new byte[(int) (0)];
;
 //BA.debugLineNum = 114;BA.debugLine="b = m.Sign";
_b = _m.Sign();
 //BA.debugLineNum = 115;BA.debugLine="Return bc.HexFromBytes(b)";
if (true) return _bc.HexFromBytes(_b);
 //BA.debugLineNum = 117;BA.debugLine="End Sub";
return "";
}
public static String  _gethashbase64(String _inp) throws Exception{
anywheresoftware.b4a.agraham.byteconverter.ByteConverter _bc = null;
anywheresoftware.b4a.objects.StringUtils _su = null;
String _res = "";
 //BA.debugLineNum = 85;BA.debugLine="Sub getHashBase64(inp As String) As String";
 //BA.debugLineNum = 87;BA.debugLine="Dim bc As ByteConverter";
_bc = new anywheresoftware.b4a.agraham.byteconverter.ByteConverter();
 //BA.debugLineNum = 88;BA.debugLine="Dim su As StringUtils";
_su = new anywheresoftware.b4a.objects.StringUtils();
 //BA.debugLineNum = 90;BA.debugLine="Dim res As String =  su.EncodeBase64(bc.HexToB";
_res = _su.EncodeBase64(_bc.HexToBytes(_inp));
 //BA.debugLineNum = 92;BA.debugLine="res=res.Replace(\"+\",\"-\")";
_res = _res.replace("+","-");
 //BA.debugLineNum = 93;BA.debugLine="res=res.Replace(\"/\",\"_\")";
_res = _res.replace("/","_");
 //BA.debugLineNum = 96;BA.debugLine="If res.EndsWith(\"=\") Then ' remove padding";
if (_res.endsWith("=")) { 
 //BA.debugLineNum = 97;BA.debugLine="res = res.Replace(\"=\",\"\")";
_res = _res.replace("=","");
 };
 //BA.debugLineNum = 100;BA.debugLine="Return res";
if (true) return _res;
 //BA.debugLineNum = 102;BA.debugLine="End Sub";
return "";
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 8;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 9;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 10;BA.debugLine="Private Button1 As B4XView";
_button1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 14;BA.debugLine="End Sub";
return "";
}
}
